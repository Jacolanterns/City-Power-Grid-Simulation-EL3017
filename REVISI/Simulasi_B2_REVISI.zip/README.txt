Pengerjaan soal nomor 7 menggunakan file normal, dan nomor 9 menggunakan file genset.
Keduanya dilakukan pada file tersebut karena hanya perlu melakukan comment/uncomment.